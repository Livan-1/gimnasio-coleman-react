// ✅ src/__tests__/Cart.test.js
// Pruebas unitarias del componente Cart.js
// Se centra en la visibilidad, renderizado de productos y llamadas de eventos

import { render, screen, within, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import Cart from "../components/Cart";

const mockItems = [
  { id: 1, name: "Guantes Coleman", price: 10000, quantity: 2 },
  { id: 2, name: "Botella Deportiva", price: 8000, quantity: 1 }
];

describe("Cart Component", () => {

  test("renderiza productos del carrito correctamente", () => {
    render(<Cart items={mockItems} isVisible={true} />);
    expect(screen.getByText(/guantes coleman/i)).toBeInTheDocument();
    expect(screen.getByText(/botella deportiva/i)).toBeInTheDocument();
  });

  test("muestra el total correctamente calculado", () => {
    render(<Cart items={mockItems} isVisible={true} />);
    expect(screen.getByText(/total/i)).toBeInTheDocument();
  });

  test("no se muestra visualmente cuando isVisible=false", async () => {
    render(<Cart items={mockItems} isVisible={false} />);
    const total = screen.queryByText(/total/i);
    if (total) {
      const contenedor = total.closest("aside") || total.closest("div");
      expect(contenedor).toHaveClass("hidden", { exact: false });
    }
  });

  test("dispara callbacks al presionar los botones", async () => {
    const mockAdd = jest.fn();
    const mockRemove = jest.fn();
    const mockDelete = jest.fn();

    render(
      <Cart
        items={mockItems}
        isVisible={true}
        onAdd={mockAdd}
        onRemove={mockRemove}
        onDelete={mockDelete}
      />
    );

    const user = userEvent.setup();
    const carrito = screen.getByText(/total/i).closest("aside");

    // Botones +, -, eliminar
    const botonesMas = within(carrito).getAllByRole("button", { name: /\+/i });
    const botonesMenos = within(carrito).getAllByRole("button", { name: /menos|−|-/i });
    const botonesEliminar = within(carrito).getAllByRole("button", { name: /eliminar|quitar/i });

    await user.click(botonesMas[0]);
    await user.click(botonesMenos[0]);
    await user.click(botonesEliminar[0]);

    expect(mockAdd).toHaveBeenCalled();
    expect(mockRemove).toHaveBeenCalled();
    expect(mockDelete).toHaveBeenCalled();
  });

  test("permite cerrar el carrito con el botón de cierre", async () => {
    const mockClose = jest.fn();
    const user = userEvent.setup();
    render(<Cart items={mockItems} isVisible={true} onClose={mockClose} />);
    const botonCerrar = screen.getByRole("button", { name: /cerrar/i });
    await user.click(botonCerrar);
    expect(mockClose).toHaveBeenCalled();
  });

});
