/**
 * Pruebas de integración ligera para App.js
 * Usando React Testing Library (RTL) + Jest.
 * 
 * Corrige los errores de:
 * - "Found multiple elements with role button and name /carrito/i"
 * - Tiempo de espera de renderización (timeout en waitFor)
 * 
 * Se agrega búsqueda específica por texto exacto del botón “Carrito”
 * para evitar confusión con “Cerrar carrito”.
 */

import React from 'react';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import App from '../App';

describe('App (Integración completa)', () => {

  // --- Utilidad para hacer clic en el botón principal del carrito ---
  async function clickMainCartButton() {
    const [botonCarrito] = await screen.findAllByRole('button', { name: /^carrito$/i });
    await userEvent.click(botonCarrito);
  }

  test('agregar un producto incrementa el contador en el Header', async () => {
    const user = userEvent.setup();
    render(<App />);

    const addButtons = await screen.findAllByRole('button', { name: /agregar/i });
    await user.click(addButtons[0]);

    expect(await screen.findByText('1')).toBeInTheDocument();
  });

  test('agregar el mismo producto dos veces incrementa cantidad (no productos distintos)', async () => {
    const user = userEvent.setup();
    render(<App />);

    const addButtons = await screen.findAllByRole('button', { name: /agregar/i });
    await user.click(addButtons[0]);
    await user.click(addButtons[0]);

    // Abre el carrito (usa función auxiliar)
    await clickMainCartButton();

    // La cantidad total debería reflejar 2 unidades del mismo producto
    expect(await screen.findByText('2')).toBeInTheDocument();
  });

  test('disminuir hasta 0 elimina el ítem del carrito', async () => {
    const user = userEvent.setup();
    render(<App />);

    const addButtons = await screen.findAllByRole('button', { name: /agregar/i });
    await user.click(addButtons[0]);

    await clickMainCartButton();

    // Busca el botón de disminuir cantidad (aria-label configurado)
    const botonMenos = await screen.findByRole('button', { name: /disminuir cantidad/i });
    await user.click(botonMenos);

    // Cierra carrito y valida que el contador vuelva a 0
    const closeBtn = screen.getByRole('button', { name: /cerrar carrito/i });
    await user.click(closeBtn);

    expect(await screen.findByText('0')).toBeInTheDocument();
  });

  test('eliminar producto actualiza total y contador', async () => {
    const user = userEvent.setup();
    render(<App />);

    const addButtons = await screen.findAllByRole('button', { name: /agregar/i });
    await user.click(addButtons[0]);

    await clickMainCartButton();

    const eliminarBtn = await screen.findByRole('button', { name: /eliminar producto/i });
    await user.click(eliminarBtn);

    // El total debe desaparecer del DOM
    await screen.findByText(/total/i);
    expect(screen.queryByText(/guantes coleman/i)).not.toBeInTheDocument();
  });

  test('abrir y cerrar carrito funciona correctamente', async () => {
    const user = userEvent.setup();
    render(<App />);

    // Abrir carrito desde el header
    await clickMainCartButton();

    // Comprobar que se muestre el aside con aria-label
    const carrito = await screen.findByRole('complementary', { name: /carrito de compras/i });
    expect(carrito).toBeVisible();

    // Cerrar el carrito
    const closeBtn = screen.getByRole('button', { name: /cerrar carrito/i });
    await user.click(closeBtn);

    // Validar que el carrito ya no esté visible
    expect(carrito.className).not.toContain('show');
  });
});
