// ✅ src/__tests__/Store.test.js
// Pruebas del componente Store.js
// Evalúa renderizado de productos, interacción con filtros y botones de agregar

import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import Store from "../components/Store";

const mockProducts = [
  { id: 1, name: "Guantes Coleman", price: 10000, category: "fuerza" },
  { id: 2, name: "Botella Deportiva", price: 8000, category: "cardio" },
  { id: 3, name: "Bandas Elásticas", price: 12000, category: "flexibilidad" }
];

describe("Store Component", () => {

  test("renderiza productos correctamente", () => {
    render(<Store products={mockProducts} />);
    expect(screen.getByText(/guantes coleman/i)).toBeInTheDocument();
    expect(screen.getByText(/botella deportiva/i)).toBeInTheDocument();
  });

  test("cada producto tiene botón 'Agregar'", () => {
    render(<Store products={mockProducts} />);
    const botones = screen.getAllByRole("button", { name: /agregar/i });
    expect(botones.length).toBe(mockProducts.length);
  });

  test("filtra productos por categoría seleccionada", async () => {
    render(<Store products={mockProducts} />);
    const selectCategoria = screen.getByLabelText(/categoría/i);
    const user = userEvent.setup();
    await user.selectOptions(selectCategoria, "cardio");
    await waitFor(() => {
      expect(screen.getByText(/botella deportiva/i)).toBeInTheDocument();
    });
  });

  test("dispara evento onAdd al hacer click en 'Agregar'", async () => {
    const mockAdd = jest.fn();
    const user = userEvent.setup();
    render(<Store products={mockProducts} onAdd={mockAdd} />);
    const botones = screen.getAllByRole("button", { name: /agregar/i });
    await user.click(botones[0]);
    expect(mockAdd).toHaveBeenCalledTimes(1);
  });

  test("muestra mensaje cuando no hay productos disponibles", () => {
    render(<Store products={[]} />);
    expect(screen.getByText(/no hay productos disponibles/i)).toBeInTheDocument();
  });

});
