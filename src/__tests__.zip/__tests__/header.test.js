// ✅ src/__tests__/Header.test.js
// Pruebas del componente Header.js
// Verifica que los botones principales y las funciones recibidas por props funcionen correctamente

import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import Header from "../components/Header";

describe("Header Component", () => {

  test("renderiza los botones del header correctamente", () => {
    render(<Header />);
    expect(screen.getByRole("button", { name: /menú/i })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /ingresar/i })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /carrito/i })).toBeInTheDocument();
  });

  test("dispara el evento de login cuando se presiona 'Ingresar'", async () => {
    const mockLogin = jest.fn();
    render(<Header onLoginClick={mockLogin} />);
    const user = userEvent.setup();
    await user.click(screen.getByRole("button", { name: /ingresar/i }));
    expect(mockLogin).toHaveBeenCalledTimes(1);
  });

  test("dispara el evento del carrito al presionar 'Carrito'", async () => {
    const mockCart = jest.fn();
    render(<Header onCartClick={mockCart} />);
    const user = userEvent.setup();
    await user.click(screen.getByRole("button", { name: /carrito/i }));
    expect(mockCart).toHaveBeenCalledTimes(1);
  });

  test("el header contiene la clase base y estructura esperada", () => {
    render(<Header />);
    const header = screen.getByRole("banner");
    expect(header).toBeInTheDocument();
  });

  test("los botones son accesibles mediante roles y texto", () => {
    render(<Header />);
    const buttons = screen.getAllByRole("button");
    expect(buttons.length).toBeGreaterThanOrEqual(3);
  });

});
