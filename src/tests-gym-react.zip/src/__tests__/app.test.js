/**
 * Pruebas con React Testing Library (RTL) + Jest
 * - Ejecuta con: `npm test`
 * - Si algún selector no calza con tu UI (texto del botón, alt de imagen, etc.),
 *   ajusta el `name`/`text` del `getByRole`/`getByText` según tu componente.
 */
import React from 'react';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

import App from '../../App';

// Nota: Estas pruebas son más integradas. Si algún selector no coincide con tu UI real,
// ajusta los textos/roles (por ejemplo, el botón de "Agregar" o "Carrito").

describe('App (integración ligera)', () => {
  test('agregar un producto incrementa el contador de Header', async () => {
    const user = userEvent.setup();
    render(<App />);
    // Click en el primer botón "Agregar" de la tienda
    const addButtons = await screen.findAllByRole('button', { name: /agregar/i });
    await user.click(addButtons[0]);

    // El header debería reflejar la suma (1)
    expect(await screen.findByText('1')).toBeInTheDocument();
  });

  test('agregar el mismo producto dos veces incrementa quantity, no ítems distintos', async () => {
    const user = userEvent.setup();
    render(<App />);

    const addButtons = await screen.findAllByRole('button', { name: /agregar/i });
    await user.click(addButtons[0]);
    await user.click(addButtons[0]);

    // Abre el carrito desde el header
    const cartBtn = screen.getByRole('button', { name: /carrito/i });
    await user.click(cartBtn);

    // Debe existir una sola fila del producto, pero cantidad 2 (la UI puede mostrar "2")
    // Para simplificar, comprobamos que el contador general sea "2".
    expect(await screen.findByText('2')).toBeInTheDocument();
  });

  test('disminuir hasta 0 elimina el item del carrito', async () => {
    const user = userEvent.setup();
    render(<App />);

    const addButtons = await screen.findAllByRole('button', { name: /agregar/i });
    await user.click(addButtons[0]); // qty 1
    // abrir carrito
    const cartBtn = screen.getByRole('button', { name: /carrito/i });
    await user.click(cartBtn);

    // Disminuir (debería eliminarse porque estaba en 1)
    const minus = screen.getByRole('button', { name: /−|-|menos/i });
    await user.click(minus);

    // Ya no debería verse el producto (buscamos el botón "Pagar" como ancla y que no aparezca el nombre). 
    // Como fallback, comprobamos que el contador del header vuelva a 0
    const close = screen.getByRole('button', { name: /cerrar|close|×/i });
    await user.click(close);
    expect(await screen.findByText('0')).toBeInTheDocument();
  });

  test('remover item actualiza el total y contador', async () => {
    const user = userEvent.setup();
    render(<App />);
    const addButtons = await screen.findAllByRole('button', { name: /agregar/i });
    await user.click(addButtons[0]);
    await user.click(addButtons[1]);

    // abrir carrito
    const cartBtn = screen.getByRole('button', { name: /carrito/i });
    await user.click(cartBtn);

    // Eliminar uno de los artículos (texto del botón puede ser "Eliminar")
    const removeBtns = screen.getAllByRole('button', { name: /eliminar|quitar/i });
    await user.click(removeBtns[0]);

    // Cerrar y verificar contador (debería ser 1)
    const close = screen.getByRole('button', { name: /cerrar|close|×/i });
    await user.click(close);
    expect(await screen.findByText('1')).toBeInTheDocument();
  });

  test('abrir y cerrar el carrito desde Header funciona', async () => {
    const user = userEvent.setup();
    render(<App />);
    const cartBtn = screen.getByRole('button', { name: /carrito/i });
    await user.click(cartBtn);
    // Ahora debería verse el panel del carrito (busca "Total" o el botón Pagar)
    expect(await screen.findByText(/total/i)).toBeInTheDocument();

    const close = screen.getByRole('button', { name: /cerrar|close|×/i });
    await user.click(close);
    expect(screen.queryByText(/total/i)).not.toBeInTheDocument();
  });
});
