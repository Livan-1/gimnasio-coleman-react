/**
 * Pruebas con React Testing Library (RTL) + Jest
 * - Ejecuta con: `npm test`
 * - Si algún selector no calza con tu UI (texto del botón, alt de imagen, etc.),
 *   ajusta el `name`/`text` del `getByRole`/`getByText` según tu componente.
 */
import React from 'react';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

import Store from '../../components/Store';

const mockProducts = [
  { sku: 'AC-001', name: 'Guantes Coleman', price: 10000, image: '/guantes_fake_coleman.jpg' },
  { sku: 'AC-002', name: 'Botella Deportiva', price: 8000, image: '/botella_fake_coleman.jpg' },
  { sku: 'AC-003', name: 'Bandas Elásticas', price: 12000, image: '/bandas_fake_coleman.jpg' },
];

describe('Store', () => {
  test('renderiza la cantidad correcta de productos', () => {
    render(<Store products={mockProducts} onAddToCart={() => {}} />);
    // Asumimos que cada producto tiene un botón "Agregar"
    const buttons = screen.getAllByRole('button', { name: /agregar/i });
    expect(buttons).toHaveLength(mockProducts.length);
  });

  test('muestra nombre y precio por producto', () => {
    render(<Store products={mockProducts} onAddToCart={() => {}} />);
    expect(screen.getByText(/guantes coleman/i)).toBeInTheDocument();
    // Precio en CLP (puede variar el formato). Ajusta si tu template es distinto.
    expect(screen.getByText(/\$?\s*10\.?000|10,?000/)).toBeInTheDocument();
  });

  test('cada imagen tiene alt con el nombre del producto', () => {
    render(<Store products={mockProducts} onAddToCart={() => {}} />);
    mockProducts.forEach(p => {
      const img = screen.getByAltText(new RegExp(p.name, 'i'));
      expect(img).toBeInTheDocument();
    });
  });

  test('al hacer click en Agregar se llama onAddToCart con el producto', async () => {
    const user = userEvent.setup();
    const onAddToCart = jest.fn();
    render(<Store products={mockProducts} onAddToCart={onAddToCart} />);

    const firstAdd = screen.getAllByRole('button', { name: /agregar/i })[0];
    await user.click(firstAdd);
    expect(onAddToCart).toHaveBeenCalledTimes(1);
    // El primer argumento debería ser el producto completo
    expect(onAddToCart.mock.calls[0][0]).toMatchObject({ sku: 'AC-001' });
  });

  test('dos clicks en Agregar disparan dos llamadas (incrementos)', async () => {
    const user = userEvent.setup();
    const onAddToCart = jest.fn();
    render(<Store products={mockProducts} onAddToCart={onAddToCart} />);

    const firstAdd = screen.getAllByRole('button', { name: /agregar/i })[0];
    await user.click(firstAdd);
    await user.click(firstAdd);
    expect(onAddToCart).toHaveBeenCalledTimes(2);
  });
});
