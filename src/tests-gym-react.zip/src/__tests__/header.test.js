/**
 * Pruebas con React Testing Library (RTL) + Jest
 * - Ejecuta con: `npm test`
 * - Si algún selector no calza con tu UI (texto del botón, alt de imagen, etc.),
 *   ajusta el `name`/`text` del `getByRole`/`getByText` según tu componente.
 */
import React from 'react';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

import Header from '../../components/Header';

describe('Header', () => {
  test('renderiza marca y navegación básica', () => {
    render(<Header onCartClick={() => {}} onLoginClick={() => {}} cartItemCount={0} />);
    // Ajusta estos textos si tu marca/título difiere
    expect(screen.getByText(/coleman/i)).toBeInTheDocument();
  });

  test('muestra el contador del carrito', () => {
    render(<Header onCartClick={() => {}} onLoginClick={() => {}} cartItemCount={3} />);
    // Busca un badge/elemento que contenga el número 3
    expect(screen.getByText('3')).toBeInTheDocument();
  });

  test('dispara onCartClick al presionar el botón Carrito', async () => {
    const user = userEvent.setup();
    const onCartClick = jest.fn();
    render(<Header onCartClick={onCartClick} onLoginClick={() => {}} cartItemCount={0} />);

    // Ajusta el nombre si tu botón se llama distinto (e.g., "Ver Carrito")
    const btn = screen.getByRole('button', { name: /carrito/i });
    await user.click(btn);
    expect(onCartClick).toHaveBeenCalledTimes(1);
  });

  test('dispara onLoginClick al presionar el botón Login', async () => {
    const user = userEvent.setup();
    const onLoginClick = jest.fn();
    render(<Header onCartClick={() => {}} onLoginClick={onLoginClick} cartItemCount={0} />);

    const btn = screen.getByRole('button', { name: /login|ingresar/i });
    await user.click(btn);
    expect(onLoginClick).toHaveBeenCalledTimes(1);
  });

  test('no crashea si el contador es 0 y los handlers están definidos', () => {
    render(<Header onCartClick={() => {}} onLoginClick={() => {}} cartItemCount={0} />);
    // Si renderiza, la prueba pasa.
    expect(screen.getByText(/coleman/i)).toBeInTheDocument();
  });
});
