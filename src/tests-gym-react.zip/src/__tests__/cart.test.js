/**
 * Pruebas con React Testing Library (RTL) + Jest
 * - Ejecuta con: `npm test`
 * - Si algún selector no calza con tu UI (texto del botón, alt de imagen, etc.),
 *   ajusta el `name`/`text` del `getByRole`/`getByText` según tu componente.
 */
import React from 'react';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

import Cart from '../../components/Cart';

const items = [
  { sku: 'AC-001', name: 'Guantes Coleman', price: 10000, image: '/guantes_fake_coleman.jpg', quantity: 2 },
  { sku: 'AC-002', name: 'Botella Deportiva', price: 8000, image: '/botella_fake_coleman.jpg', quantity: 1 },
];

describe('Cart', () => {
  test('no se muestra cuando isVisible=false', () => {
    render(<Cart isVisible={false} onClose={() => {}} items={[]} onRemoveItem={() => {}} onDecreaseItem={() => {}} onIncreaseItem={() => {}} />);
    // Asumimos que el aside con role="complementary" o el texto "Total" no aparece
    expect(screen.queryByText(/total/i)).not.toBeInTheDocument();
  });

  test('se muestra cuando isVisible=true', () => {
    render(<Cart isVisible={true} onClose={() => {}} items={items} onRemoveItem={() => {}} onDecreaseItem={() => {}} onIncreaseItem={() => {}} />);
    // Debe mostrar los nombres de los productos
    expect(screen.getByText(/guantes coleman/i)).toBeInTheDocument();
    expect(screen.getByText(/botella deportiva/i)).toBeInTheDocument();
  });

  test('calcula el total correctamente', () => {
    render(<Cart isVisible={true} onClose={() => {}} items={items} onRemoveItem={() => {}} onDecreaseItem={() => {}} onIncreaseItem={() => {}} />);
    // 2*10000 + 1*8000 = 28000
    expect(screen.getByText(/28\.?000|28,?000/)).toBeInTheDocument();
  });

  test('disminuir, aumentar y eliminar disparan callbacks', async () => {
    const user = userEvent.setup();
    const onDecreaseItem = jest.fn();
    const onIncreaseItem = jest.fn();
    const onRemoveItem = jest.fn();
    render(<Cart isVisible={true} onClose={() => {}} items={items} onRemoveItem={onRemoveItem} onDecreaseItem={onDecreaseItem} onIncreaseItem={onIncreaseItem} />);

    const firstRow = screen.getByText(/guantes coleman/i).closest('article') || screen.getByText(/guantes coleman/i).closest('div');
    // Ajusta si tus controles tienen textos distintos
    const minus = within(firstRow).getByRole('button', { name: /−|-|menos/i });
    const plus  = within(firstRow).getByRole('button', { name: /\+|mas|más/i });
    const remove = within(firstRow).getByRole('button', { name: /eliminar|quitar/i });

    await user.click(minus);
    await user.click(plus);
    await user.click(remove);

    expect(onDecreaseItem).toHaveBeenCalled();
    expect(onIncreaseItem).toHaveBeenCalled();
    expect(onRemoveItem).toHaveBeenCalled();
  });

  test('cerrar carrito llama onClose', async () => {
    const user = userEvent.setup();
    const onClose = jest.fn();
    render(<Cart isVisible={true} onClose={onClose} items={items} onRemoveItem={() => {}} onDecreaseItem={() => {}} onIncreaseItem={() => {}} />);
    // Ajusta el selector si usas otro texto/icono para cerrar
    const closeBtn = screen.getByRole('button', { name: /cerrar|close|×/i });
    await user.click(closeBtn);
    expect(onClose).toHaveBeenCalledTimes(1);
  });
});
